from enum import Enum, auto


class Theme(Enum):
    dark = auto()
    light = auto()