# Qtica
__version__ = "0.3.2"
__version_info__ = (0, 3, 2, "", "")

# Python
__minimum_python_version__ = (3, 10)
__maximum_python_version__ = (3, 12)

# PySide6
__pyside_version__ = "6.5.0"


from .core import *