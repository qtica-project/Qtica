# Qtica
__version__ = "0.3.1"
__version_info__ = (0, 3, 1, "", "")

# Python
__minimum_python_version__ = (3, 7)
__maximum_python_version__ = (3, 12)

# PySide6
__pyside_version__ = "6.6.1"


from .core import *