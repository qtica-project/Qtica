#!/usr/bin/python3

class MacOSInit:
	def __init__(self) -> None:
		...