#!/usr/bin/python3

from .base import BaseInit


class LinuxInit(BaseInit):
	def __init__(self) -> None:
		super().__init__()