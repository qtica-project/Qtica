from .display_large_text import LargTextDialog
from .silent_mode import SilentTextDialog