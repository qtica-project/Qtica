from .teaching_tip.tool_tip import TeachingTipDialog
from .silent import SilentDialog
from .mask import MaskDialog