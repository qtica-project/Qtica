from .view import QuickView
from .widget import QuickWidget