# -*- coding: utf-8 -*-
from .frontend import TerminalWidget