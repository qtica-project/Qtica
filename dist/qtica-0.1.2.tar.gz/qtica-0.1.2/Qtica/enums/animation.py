from enum import IntEnum


class AnimationPath(IntEnum):
    linear: int = 0
    circle: int = 1