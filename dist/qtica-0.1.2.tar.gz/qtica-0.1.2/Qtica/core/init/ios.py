#!/usr/bin/python3

class IOSInit:
	def __init__(self) -> None:
		...