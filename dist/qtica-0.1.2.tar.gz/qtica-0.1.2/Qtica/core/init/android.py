#!/usr/bin/python3

class AndroidInit:
	def __init__(self) -> None:
		...