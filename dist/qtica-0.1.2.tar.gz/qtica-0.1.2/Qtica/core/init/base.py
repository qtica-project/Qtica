
class BaseInit:
    def __init__(self):
        ...