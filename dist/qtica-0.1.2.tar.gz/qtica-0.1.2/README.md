<p align="center">
  <a href="https://omamkaz.gitbook.io/qtica-docs/quick-start">
    <img alt="Qtica" src="./logo.png">
  </a>
</p>

<p align="center">
  A Fast Way to Done Your Idea!
</p>

Qtica is a Python library that provides a lightweight API around native PySide6, allowing for lightning-fast GUI prototyping using modern declarative UI techniques entirely within Python.

# Documention

[Get Start](https://omamkaz.gitbook.io/qtica-docs/quick-start)
